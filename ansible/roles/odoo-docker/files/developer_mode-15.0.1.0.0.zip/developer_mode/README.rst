================================
   Automatic Developer Mode  v15
================================

Odoo Developers, Keep smiling for the below reasons:

 * Automatically Trigger Developer Mode.
 * Separate Group for 'Odoo Developers'.
 * Upgrade Modules Easily.
 * Recently Upgraded Filter.

Credits
-------
* `Nilmar Shereef < odoo@cybsosys.com >`
* `Saritha < odoo@cybsosys.com >`


Further information
===================
HTML Description: `<static/description/index.html>`__

